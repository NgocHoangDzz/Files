document.addEventListener('DOMContentLoaded', () => {
    const mainContent = document.getElementById('main-content');
    const navLinks = document.querySelectorAll('.nav-link');
    const pageContents = {
        'ai': `
            <section id="ai-section" class="section ai-section">
                <div class="container">
                    <h2>Free AI</h2>
                    <p>Chào mừng bạn đến với trang AI miễn phí của chúng tôi! Tại đây, bạn có thể tương tác với các mô hình AI tiên tiến.</p>
                    <p>Hãy thử hỏi AI bất cứ điều gì!</p>
                </div>
            </section>`,
            
        'contact': `
            <section id="contact" class="section contact-section">
            <div class="container">
            <h2>Liên hệ</h2>
            <p>bạn cần hỗ trợ? Hãy gửi email cho tôi!</p>
                
                <form action="https://getform.io/f/allzrmla" method="POST" class="contact-form">
                    <div class="form-group">
                        <label for="name">Họ và tên:</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                        
                    <div class="form-group">
                        <label for="phone">SDT:</label>
                        <input type="text" id="phone" name="phone" required>
                    </div>
                        
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="_replyto" required>
                    </div>
                        
                    <div class="form-group">
                        <label for="message">Tin nhắn:</label>
                        <textarea id="message" name="message" rows="5" required></textarea>
                    </div>
                        
                    <button type="submit" class="button">Gửi tin nhắn</button>
                </form>
                    <p id="formStatus" class="form-status"></p>
                </div>
            </section>`,
            
        'login': `
            <section id="login-section" class="section login-section full-screen-section">
                <div class="box">
                    <div class="form">
                        <h2><i class="fas fa-user"></i>LOGIN</h2>
                        <div class="inputbox">
                            <input type="text" id="username" required>
                            <span>Username</span>
                                    <i></i>
                        </div>
                        <div class="inputbox">
                            <input type="password" id="password" required>
                            <span>Password</span>
                            <i></i>
                        </div>
                        <div class="link">
                            <a href="https://discord.gg/YkRK3DRHN4" target="_blank">Quên mật khẩu?</a>
                            <a href="https://discord.gg/YkRK3DRHN4" target="_blank">Tham gia Discord</a>
                        </div>
                        <button type="submit" class="login-btn" id="login-button">LOG IN</button>
                        <p id="login-message" class="login-message"></p>
                    </div>
                </div>
            </section>
            <!-- Login -->
            <script>
                <!-- thêm script login -->
                    </script>`
            };

    function loadPage(pageName) {
        const content = pageContents[pageName];
        if (content) {
            mainContent.innerHTML = content;
            window.scrollTo({ top: 0, behavior: 'smooth' });
            history.pushState({ page: pageName }, '', `#${pageName}`);
        } else {
            mainContent.innerHTML = `<section class="section"><div class="container"><h2>Trang không tìm thấy</h2><p>Nội dung bạn tìm kiếm không tồn tại.</p></div></section>`;
            history.pushState({ page: '404' }, '', `#404`);
        }
        document.getElementById('sidebar-active').checked = false;
    }

        navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            if (link.hasAttribute('target') && link.getAttribute('target') === '_blank') {
                return;
            }
            e.preventDefault();
            const pageName = link.getAttribute('data-page');
            if (pageName) {
                        loadPage(pageName);
            } else {
                const href = link.getAttribute('href');
                if (href && href.startsWith('#')) {
                    const targetElement = document.querySelector(href);
                    if (targetElement) {
                        targetElement.scrollIntoView({ behavior: 'smooth' });
                    }
                }
            }
        });
    });

    window.addEventListener('popstate', (event) => {
        if (event.state && event.state.page) {
            loadPage(event.state.page);
        } else {
            loadPage('home');
        }
    });
    const initialHash = window.location.hash.substring(1);
    if (initialHash === 'login' && sessionStorage.getItem("loggedIn") === "true") {
        loadPage('home');
    } else {
        loadPage(initialHash || 'home');
    }

        if (sessionStorage.getItem("loggedIn") !== "true") {
    }
});